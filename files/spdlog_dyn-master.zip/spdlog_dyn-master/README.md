https://gitee.com/jeasonb/spdlog_dyn
使用的方法可以参考这个博客  ： 
https://jeason.blog.csdn.net/article/details/123032819