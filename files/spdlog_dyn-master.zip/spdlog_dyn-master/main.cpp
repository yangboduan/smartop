#include <spdlog.h>

int main(int argc,char ** argv)
{
    spdlog::info("12323123");
    spdlog::info("12323123");
    spdlog::info("12323123");
    return 0;
}