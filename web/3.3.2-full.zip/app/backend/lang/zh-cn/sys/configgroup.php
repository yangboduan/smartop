<?php

return [
    'Config Group' => '配置分组',
    'Group name' => '分组名',
    'Group title' => '分组标题',
    'Group has config' => '分组下有配置',

];