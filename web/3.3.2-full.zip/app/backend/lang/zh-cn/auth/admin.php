<?php

return [
    'AuthGroup' => '权限组',
    'oldpassword' => '旧密码',
    'NewPasswd' => '新密码',
    'Renewpasswd' => '重复新密码',
    'Group_Id' => '权限分组',
    'Supper man cannot delete' => '超级管理员不能删除',
    'Supper man cannot edit' => '超级管理员不能修改',
    'Supper man cannot edit state' => '超级管理员不能修改状态',
    'Origin Password Error' => '原密码错误',
    'Username is between 4 and 25 characters'=>'用户名在4-25个字符',
    'Password must be greater than 6 characters and less than 15 characters'=>'密码在6-15个字符',
    'realname' => '姓名',
    'For password retrieval please fill in carefully'=>'找回密码请认真填写',
];