<?php

\think\facade\Route::get('/','frontend/index/index');
